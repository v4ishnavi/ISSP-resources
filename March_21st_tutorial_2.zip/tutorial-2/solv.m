clc, clearvars, close all;
% x[n] + a1* x[n-1] + a2* x[n-2] = v[n] 
% x[n-1] + a2* x[n-2]